This is brief documentation for The US-AR-Tr Keyboard. It is aimed to ease the typing of Arabic Transliteration on a standard US QWERTY Keyboard.

#############################################################################################
Steps to Install:
1) in 'us-ar-tr' run 'setup.exe'
2) Go to the 'Control Panel'
3) Go to 'Clock, Language, and Region'
4) On the 'English (United States)', select 'Options'
5) Under 'Input method' click 'Add an input method'
6) Find 'US - AR Transliteration', select it, and click 'Add'
7) For the previois 'US' option, click 'Remove'

You should now be able to use this keyboard. If you encouter any issues, or find that the keyboard doesn't work, close the 'Control Panel', and repeat the instructions. If not, simply Restart your computer.

#############################################################################################
How to Use:
All non-standard inputs are accesible by using Ctrl+Alt or Shift+Ctrl+Alt.

Ctrl+Alt+ 'Your Input':
'			- ʿ
-			- — (em dash)
a|i|u 		- ā|ī|ū
d|h|s|t|z 	- ḍ|ḥ|ṣ|ṭ|ẓ
b 			- ﷽
g 			- ﷻ
r 			- ﷺ
p 			- (ع)
c 			- (Rḍ)

Shift(Caps On)+Ctrl+Alt+ 'Your Input':
'			- ʾ
A|I|U 		- Ā|Ī|Ū
D|H|S|T|Z 	- Ḍ|Ḥ|Ṣ|Ṭ|Ẓ
